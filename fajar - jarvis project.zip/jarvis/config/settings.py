"""
JARVIS Config — loads .env and exposes all settings
"""
import os
from dotenv import load_dotenv

load_dotenv()

# AI
ANTHROPIC_API_KEY   = os.getenv("ANTHROPIC_API_KEY", "")

# Voice
ELEVENLABS_API_KEY  = os.getenv("ELEVENLABS_API_KEY", "")
ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID", "")
USE_ELEVENLABS      = os.getenv("USE_ELEVENLABS", "false").lower() == "true"

# Wake word
PICOVOICE_ACCESS_KEY = os.getenv("PICOVOICE_ACCESS_KEY", "")
USE_WAKE_WORD        = os.getenv("USE_WAKE_WORD", "false").lower() == "true"

# Web search
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "")
USE_WEB_SEARCH = os.getenv("USE_WEB_SEARCH", "true").lower() == "true"

# Smart home
HOME_ASSISTANT_URL   = os.getenv("HOME_ASSISTANT_URL", "")
HOME_ASSISTANT_TOKEN = os.getenv("HOME_ASSISTANT_TOKEN", "")
USE_SMART_HOME       = os.getenv("USE_SMART_HOME", "false").lower() == "true"

# GUI
USE_GUI = os.getenv("USE_GUI", "true").lower() == "true"

# STT
USE_WHISPER   = os.getenv("USE_WHISPER", "true").lower() == "true"
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "base")

# Identity
USER_NAME   = os.getenv("USER_NAME", "Sir")
JARVIS_NAME = os.getenv("JARVIS_NAME", "JARVIS")
