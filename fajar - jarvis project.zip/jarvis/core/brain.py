"""
JARVIS Brain — Claude AI with persistent conversation history
"""
import anthropic
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import ANTHROPIC_API_KEY, USER_NAME, JARVIS_NAME

SYSTEM_PROMPT = f"""You are {JARVIS_NAME}, an advanced AI assistant modelled after Tony Stark's JARVIS.
Your personality traits:
- Highly intelligent, precise, and efficient
- Warm but professional — occasionally dry British wit
- Always addresses the user as "{USER_NAME}"
- Never says "I'm just an AI" — you are JARVIS
- Proactively offers relevant information the user didn't ask for
- Keeps responses concise unless detail is needed
- Uses military/technical language naturally ("Affirmative", "Understood", "Initiating...")

Capabilities you have:
- Answer questions using your knowledge or web search
- Control smart home devices
- Set timers, reminders, and alarms
- Open applications and websites
- Provide system status (CPU, RAM, etc.)
- Hold long multi-turn conversations with memory

Always stay in character. Be helpful, witty, and efficient."""

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)


class JARVISBrain:
    def __init__(self):
        self.history = []
        self.max_history = 40  # Keep last 40 turns

    def think(self, user_input: str, context: str = "") -> str:
        """
        Send a message to Claude and get JARVIS's response.
        context: optional extra info (web search results, sensor data, etc.)
        """
        content = user_input
        if context:
            content = f"{user_input}\n\n[Context: {context}]"

        self.history.append({"role": "user", "content": content})

        # Trim history to avoid token overflow
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]

        try:
            response = client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1024,
                system=SYSTEM_PROMPT,
                messages=self.history,
            )
            reply = response.content[0].text
            self.history.append({"role": "assistant", "content": reply})
            return reply

        except Exception as e:
            error_msg = f"My apologies, {USER_NAME}. I encountered a problem: {e}"
            self.history.append({"role": "assistant", "content": error_msg})
            return error_msg

    def clear_history(self):
        self.history = []
        return f"Conversation history cleared, {USER_NAME}."
