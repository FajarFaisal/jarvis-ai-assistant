"""
JARVIS Voice — ElevenLabs premium TTS with pyttsx3 fallback
"""
import sys, os, io, threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import (
    ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID, USE_ELEVENLABS, USER_NAME
)

# ── pyttsx3 fallback engine ──────────────────────────────────────────
import pyttsx3
_tts_engine = None
_tts_lock = threading.Lock()

def _get_tts_engine():
    global _tts_engine
    if _tts_engine is None:
        _tts_engine = pyttsx3.init()
        voices = _tts_engine.getProperty("voices")
        # Try to find a British-ish male voice
        for v in voices:
            if "english" in v.name.lower() or "david" in v.name.lower():
                _tts_engine.setProperty("voice", v.id)
                break
        _tts_engine.setProperty("rate", 170)
        _tts_engine.setProperty("volume", 1.0)
    return _tts_engine


# ── ElevenLabs ───────────────────────────────────────────────────────
def _speak_elevenlabs(text: str):
    try:
        from elevenlabs import ElevenLabs, VoiceSettings
        import pygame

        el_client = ElevenLabs(api_key=ELEVENLABS_API_KEY)
        audio_gen = el_client.text_to_speech.convert(
            voice_id=ELEVENLABS_VOICE_ID,
            text=text,
            model_id="eleven_turbo_v2",
            voice_settings=VoiceSettings(
                stability=0.55,
                similarity_boost=0.85,
                style=0.15,
                use_speaker_boost=True,
            ),
        )
        # Collect bytes
        audio_bytes = b"".join(audio_gen)

        pygame.mixer.init()
        sound = pygame.mixer.Sound(io.BytesIO(audio_bytes))
        sound.play()
        # Wait for playback to finish
        while pygame.mixer.get_busy():
            pygame.time.wait(100)

    except Exception as e:
        print(f"[JARVIS] ElevenLabs error: {e} — falling back to pyttsx3")
        _speak_pyttsx3(text)


def _speak_pyttsx3(text: str):
    with _tts_lock:
        engine = _get_tts_engine()
        engine.say(text)
        engine.runAndWait()


# ── Public interface ─────────────────────────────────────────────────
def speak(text: str, silent: bool = False):
    """Speak text aloud. Pass silent=True to suppress (for testing)."""
    print(f"[JARVIS] {text}")
    if silent:
        return
    if USE_ELEVENLABS and ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID:
        _speak_elevenlabs(text)
    else:
        _speak_pyttsx3(text)


def speak_async(text: str):
    """Speak without blocking the main thread."""
    t = threading.Thread(target=speak, args=(text,), daemon=True)
    t.start()
    return t
