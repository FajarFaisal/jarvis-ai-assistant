"""
JARVIS Ears — Speech-to-Text with Whisper (local) or Google STT
"""
import speech_recognition as sr
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import USE_WHISPER, WHISPER_MODEL

recognizer = sr.Recognizer()
recognizer.energy_threshold = 300
recognizer.dynamic_energy_threshold = True
recognizer.pause_threshold = 0.8

# Load Whisper model once at startup
_whisper_model = None

def _get_whisper():
    global _whisper_model
    if _whisper_model is None:
        try:
            import whisper
            print(f"[JARVIS] Loading Whisper model '{WHISPER_MODEL}'...")
            _whisper_model = whisper.load_model(WHISPER_MODEL)
            print("[JARVIS] Whisper ready.")
        except ImportError:
            print("[JARVIS] Whisper not installed, falling back to Google STT.")
            return None
    return _whisper_model


def listen(timeout: int = 5, phrase_limit: int = 15) -> str:
    """
    Listen from the microphone and return transcribed text.
    Returns empty string on failure.
    """
    with sr.Microphone() as source:
        print("[JARVIS] Calibrating ambient noise...")
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        print("[JARVIS] Listening...")

        try:
            audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_limit)
        except sr.WaitTimeoutError:
            return ""

    if USE_WHISPER:
        return _transcribe_whisper(audio)
    else:
        return _transcribe_google(audio)


def _transcribe_whisper(audio: sr.AudioData) -> str:
    model = _get_whisper()
    if model is None:
        return _transcribe_google(audio)

    import tempfile, numpy as np
    try:
        # Convert audio to numpy array for Whisper
        raw = audio.get_raw_data(convert_rate=16000, convert_width=2)
        audio_np = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        result = model.transcribe(audio_np, language="en", fp16=False)
        text = result["text"].strip()
        print(f"[STT-Whisper] '{text}'")
        return text
    except Exception as e:
        print(f"[JARVIS] Whisper error: {e}")
        return _transcribe_google(audio)


def _transcribe_google(audio: sr.AudioData) -> str:
    try:
        text = recognizer.recognize_google(audio)
        print(f"[STT-Google] '{text}'")
        return text
    except sr.UnknownValueError:
        return ""
    except sr.RequestError as e:
        print(f"[JARVIS] Google STT error: {e}")
        return ""
