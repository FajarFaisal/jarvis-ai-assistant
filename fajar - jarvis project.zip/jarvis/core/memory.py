"""
JARVIS Memory — Long-term recall with ChromaDB vector store
Stores past conversations and facts, retrieves relevant ones.
"""
import sys, os, uuid
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

_client = None
_collection = None
DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "memory_db")


def _init():
    global _client, _collection
    if _collection is not None:
        return
    try:
        import chromadb
        _client = chromadb.PersistentClient(path=DB_PATH)
        _collection = _client.get_or_create_collection(
            name="jarvis_memory",
            metadata={"hnsw:space": "cosine"},
        )
        print(f"[JARVIS] Memory loaded ({_collection.count()} records).")
    except Exception as e:
        print(f"[JARVIS] ChromaDB unavailable: {e}. Memory disabled.")


def store(text: str, metadata: dict = None):
    """Store a piece of information in long-term memory."""
    _init()
    if _collection is None:
        return
    try:
        _collection.add(
            documents=[text],
            metadatas=[metadata or {}],
            ids=[str(uuid.uuid4())],
        )
    except Exception as e:
        print(f"[Memory] Store error: {e}")


def recall(query: str, n: int = 3) -> list[str]:
    """Retrieve the most relevant memories for a given query."""
    _init()
    if _collection is None or _collection.count() == 0:
        return []
    try:
        results = _collection.query(query_texts=[query], n_results=min(n, _collection.count()))
        return results["documents"][0] if results["documents"] else []
    except Exception as e:
        print(f"[Memory] Recall error: {e}")
        return []


def remember_exchange(user_msg: str, jarvis_reply: str):
    """Convenience: store a conversation turn."""
    store(
        text=f"User: {user_msg}\nJARVIS: {jarvis_reply}",
        metadata={"type": "conversation"},
    )


def remember_fact(fact: str):
    """Convenience: store a standalone fact."""
    store(text=fact, metadata={"type": "fact"})
