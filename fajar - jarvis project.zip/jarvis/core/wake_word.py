"""
JARVIS Wake Word — "Hey JARVIS" detection via Porcupine (Picovoice)
Falls back to a simple keyword spotter if Porcupine is unavailable.
"""
import sys, os, struct, threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import PICOVOICE_ACCESS_KEY, USE_WAKE_WORD


class WakeWordDetector:
    def __init__(self, callback):
        """
        callback: function called when wake word is detected.
        """
        self.callback  = callback
        self._running  = False
        self._thread   = None
        self._porcupine = None

    def start(self):
        if not USE_WAKE_WORD:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        print("[JARVIS] Wake word detector started. Say 'Hey JARVIS'.")

    def stop(self):
        self._running = False

    def _run(self):
        try:
            self._run_porcupine()
        except Exception as e:
            print(f"[JARVIS] Porcupine unavailable ({e}), using fallback detector.")
            self._run_fallback()

    def _run_porcupine(self):
        import pvporcupine
        import pyaudio

        porcupine = pvporcupine.create(
            access_key=PICOVOICE_ACCESS_KEY,
            keywords=["jarvis"],          # Built-in "jarvis" wake word
        )
        self._porcupine = porcupine

        pa = pyaudio.PyAudio()
        stream = pa.open(
            rate=porcupine.sample_rate,
            channels=1,
            format=pyaudio.paInt16,
            input=True,
            frames_per_buffer=porcupine.frame_length,
        )

        print(f"[JARVIS] Porcupine listening (frame={porcupine.frame_length})...")
        while self._running:
            pcm = stream.read(porcupine.frame_length, exception_on_overflow=False)
            pcm_unpacked = struct.unpack_from("h" * porcupine.frame_length, pcm)
            index = porcupine.process(pcm_unpacked)
            if index >= 0:
                print("[JARVIS] Wake word detected!")
                self.callback()

        stream.stop_stream()
        stream.close()
        pa.terminate()
        porcupine.delete()

    def _run_fallback(self):
        """
        Fallback: continuously listen for the phrase 'hey jarvis' or 'jarvis'
        using basic speech recognition.
        """
        import speech_recognition as sr
        r = sr.Recognizer()
        r.energy_threshold = 400
        r.dynamic_energy_threshold = True

        while self._running:
            try:
                with sr.Microphone() as source:
                    audio = r.listen(source, timeout=3, phrase_time_limit=4)
                text = r.recognize_google(audio).lower()
                if "jarvis" in text:
                    print(f"[JARVIS-Fallback] Wake word detected in: '{text}'")
                    self.callback()
            except Exception:
                pass
