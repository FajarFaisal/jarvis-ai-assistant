"""
JARVIS HUD — PyQt5 Iron Man-style heads-up display overlay
Run standalone or import JARVISWindow and call show().
"""
import sys, os, math, time
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QTextEdit, QLineEdit, QPushButton,
    QGraphicsDropShadowEffect,
)
from PyQt5.QtCore import (
    Qt, QTimer, QThread, pyqtSignal, QPropertyAnimation,
    QEasingCurve, QPoint, pyqtProperty,
)
from PyQt5.QtGui import (
    QColor, QPainter, QPen, QBrush, QFont, QLinearGradient,
    QPolygon, QFontDatabase,
)


# ── HUD Color Palette ────────────────────────────────────────────────
C_BG      = QColor(2, 8, 20)           # Near-black deep space
C_BLUE    = QColor(0, 168, 255)        # Arc-reactor blue
C_CYAN    = QColor(0, 229, 255)        # Bright accent
C_GOLD    = QColor(255, 180, 0)        # Iron Man gold
C_DIM     = QColor(0, 80, 130)        # Dim blue
C_TEXT    = QColor(180, 230, 255)      # Soft blue-white text
C_PANEL   = QColor(5, 20, 45, 210)    # Panel background


# ── Animated Arc Widget ───────────────────────────────────────────────
class ArcWidget(QWidget):
    """Spinning arc reactor decoration."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(120, 120)
        self._angle = 0
        self._pulse = 0.0
        self._pulse_dir = 1

        timer = QTimer(self)
        timer.timeout.connect(self._tick)
        timer.start(30)

    def _tick(self):
        self._angle = (self._angle + 2) % 360
        self._pulse += 0.05 * self._pulse_dir
        if self._pulse >= 1.0 or self._pulse <= 0.0:
            self._pulse_dir *= -1
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        cx, cy, r = 60, 60, 50

        # Outer glow ring
        pen = QPen(C_BLUE, 1.5)
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(cx - r, cy - r, r * 2, r * 2)

        # Rotating arcs
        for i, (span, offset, color, width) in enumerate([
            (240, 0,   C_CYAN, 3),
            (180, 60,  C_BLUE, 2),
            (120, 180, C_DIM,  1.5),
        ]):
            pen = QPen(color, width)
            pen.setCapStyle(Qt.RoundCap)
            p.setPen(pen)
            start = int((self._angle + offset) * 16)
            p.drawArc(cx - r + 5 * i, cy - r + 5 * i,
                      (r - 5 * i) * 2, (r - 5 * i) * 2,
                      start, span * 16)

        # Center pulse dot
        intensity = int(180 + 75 * self._pulse)
        center_color = QColor(0, intensity, 255)
        p.setBrush(QBrush(center_color))
        p.setPen(Qt.NoPen)
        dot_r = int(8 + 4 * self._pulse)
        p.drawEllipse(cx - dot_r, cy - dot_r, dot_r * 2, dot_r * 2)


# ── Status Bar Widget ─────────────────────────────────────────────────
class StatusBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(6)
        self._progress = 0.0
        self._active   = False

    def set_active(self, active: bool):
        self._active = active
        if active:
            self._progress = 0.0
        self.update()

    def set_progress(self, val: float):
        self._progress = max(0.0, min(1.0, val))
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()

        # Background track
        p.fillRect(0, 0, w, h, C_DIM)

        if self._active:
            fill_w = int(w * self._progress)
            grad = QLinearGradient(0, 0, fill_w, 0)
            grad.setColorAt(0.0, C_BLUE)
            grad.setColorAt(1.0, C_CYAN)
            p.fillRect(0, 0, fill_w, h, grad)


# ── Log Panel ─────────────────────────────────────────────────────────
class LogPanel(QTextEdit):
    def __init__(self):
        super().__init__()
        self.setReadOnly(True)
        self.setStyleSheet(f"""
            QTextEdit {{
                background: rgba(2, 8, 25, 0.85);
                color: {C_TEXT.name()};
                border: 1px solid {C_DIM.name()};
                border-radius: 6px;
                font-family: 'Courier New', monospace;
                font-size: 13px;
                padding: 8px;
            }}
        """)

    def append_user(self, text: str):
        self.append(f'<span style="color:#00e5ff;">&#9655; {text}</span>')

    def append_jarvis(self, text: str):
        self.append(f'<span style="color:#00a8ff;"><b>JARVIS:</b></span> '
                    f'<span style="color:#b4e6ff;">{text}</span>')

    def append_system(self, text: str):
        self.append(f'<span style="color:#ffb400; font-size:11px;">[SYS] {text}</span>')


# ── Main JARVIS Window ────────────────────────────────────────────────
class JARVISWindow(QMainWindow):
    # Signals for thread-safe updates
    sig_user_msg    = pyqtSignal(str)
    sig_jarvis_msg  = pyqtSignal(str)
    sig_system_msg  = pyqtSignal(str)
    sig_listening   = pyqtSignal(bool)
    sig_thinking    = pyqtSignal(bool)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("J.A.R.V.I.S")
        self.setMinimumSize(820, 600)
        self.setStyleSheet(f"background: {C_BG.name()};")
        self._init_ui()
        self._connect_signals()
        self._status_timer = QTimer(self)
        self._status_timer.timeout.connect(self._update_clock)
        self._status_timer.start(1000)

    def _init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(16, 12, 16, 12)
        root.setSpacing(10)

        # ── Header ──────────────────────────────────────────────────
        header = QHBoxLayout()
        self.arc = ArcWidget()
        header.addWidget(self.arc)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)

        lbl_title = QLabel("J.A.R.V.I.S")
        lbl_title.setStyleSheet(
            f"color: {C_CYAN.name()}; font-size: 28px; font-weight: bold; letter-spacing: 8px;"
        )
        title_col.addWidget(lbl_title)

        lbl_sub = QLabel("Just A Rather Very Intelligent System  —  v4.1")
        lbl_sub.setStyleSheet(f"color: {C_DIM.name()}; font-size: 11px; letter-spacing: 2px;")
        title_col.addWidget(lbl_sub)

        self.lbl_clock = QLabel()
        self.lbl_clock.setStyleSheet(f"color: {C_GOLD.name()}; font-size: 13px;")
        title_col.addWidget(self.lbl_clock)

        header.addLayout(title_col)
        header.addStretch()

        # Status badges
        badge_layout = QVBoxLayout()
        self.badge_listen  = self._make_badge("STANDBY", C_DIM)
        self.badge_think   = self._make_badge("IDLE", C_DIM)
        badge_layout.addWidget(self.badge_listen)
        badge_layout.addWidget(self.badge_think)
        header.addLayout(badge_layout)
        root.addLayout(header)

        # ── Status bar ───────────────────────────────────────────────
        self.status_bar = StatusBar()
        root.addWidget(self.status_bar)

        # ── Log panel ────────────────────────────────────────────────
        self.log = LogPanel()
        root.addWidget(self.log, 1)

        # ── Input row ────────────────────────────────────────────────
        input_row = QHBoxLayout()
        input_row.setSpacing(8)

        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText("Type a command or speak to JARVIS...")
        self.input_box.setStyleSheet(f"""
            QLineEdit {{
                background: rgba(0, 30, 60, 0.9);
                color: {C_TEXT.name()};
                border: 1px solid {C_BLUE.name()};
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 14px;
            }}
            QLineEdit:focus {{
                border: 1px solid {C_CYAN.name()};
            }}
        """)
        self.input_box.returnPressed.connect(self._on_send)
        input_row.addWidget(self.input_box)

        self.btn_send = QPushButton("SEND")
        self.btn_send.setFixedWidth(80)
        self.btn_send.setStyleSheet(self._btn_style(C_BLUE))
        self.btn_send.clicked.connect(self._on_send)
        input_row.addWidget(self.btn_send)

        self.btn_mic = QPushButton("🎙 MIC")
        self.btn_mic.setFixedWidth(90)
        self.btn_mic.setStyleSheet(self._btn_style(C_GOLD))
        self.btn_mic.clicked.connect(self._on_mic)
        input_row.addWidget(self.btn_mic)

        root.addLayout(input_row)

        self._update_clock()

    def _btn_style(self, color: QColor) -> str:
        return f"""
            QPushButton {{
                background: transparent;
                color: {color.name()};
                border: 1px solid {color.name()};
                border-radius: 5px;
                padding: 8px;
                font-size: 12px;
                font-weight: bold;
                letter-spacing: 1px;
            }}
            QPushButton:hover {{
                background: rgba({color.red()}, {color.green()}, {color.blue()}, 40);
            }}
        """

    def _make_badge(self, text: str, color: QColor) -> QLabel:
        lbl = QLabel(text)
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setFixedWidth(90)
        lbl.setStyleSheet(f"""
            color: {color.name()};
            border: 1px solid {color.name()};
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            letter-spacing: 2px;
            padding: 3px 6px;
        """)
        return lbl

    def _connect_signals(self):
        self.sig_user_msg.connect(self.log.append_user)
        self.sig_jarvis_msg.connect(self.log.append_jarvis)
        self.sig_system_msg.connect(self.log.append_system)
        self.sig_listening.connect(self._on_listening_change)
        self.sig_thinking.connect(self._on_thinking_change)

    def _on_listening_change(self, active: bool):
        if active:
            self.badge_listen.setText("LISTENING")
            self.badge_listen.setStyleSheet(self._make_badge("", C_CYAN).styleSheet())
            self.status_bar.set_active(True)
            self.status_bar.set_progress(0.3)
        else:
            self.badge_listen.setText("STANDBY")
            self.badge_listen.setStyleSheet(self._make_badge("", C_DIM).styleSheet())

    def _on_thinking_change(self, active: bool):
        if active:
            self.badge_think.setText("THINKING")
            self.badge_think.setStyleSheet(self._make_badge("", C_GOLD).styleSheet())
            self.status_bar.set_active(True)
            self.status_bar.set_progress(0.7)
        else:
            self.badge_think.setText("IDLE")
            self.badge_think.setStyleSheet(self._make_badge("", C_DIM).styleSheet())
            self.status_bar.set_active(False)
            self.status_bar.set_progress(0.0)

    def _update_clock(self):
        now = time.strftime("%A  %H:%M:%S")
        self.lbl_clock.setText(now)

    def _on_send(self):
        text = self.input_box.text().strip()
        if not text:
            return
        self.input_box.clear()
        if self.text_callback:
            self.text_callback(text)

    def _on_mic(self):
        if self.mic_callback:
            self.mic_callback()

    # ── External hooks ─────────────────────────────────────────────
    text_callback = None   # set by main.py
    mic_callback  = None   # set by main.py

    def show_user(self, text: str):
        self.sig_user_msg.emit(text)

    def show_jarvis(self, text: str):
        self.sig_jarvis_msg.emit(text)

    def show_system(self, text: str):
        self.sig_system_msg.emit(text)

    def set_listening(self, active: bool):
        self.sig_listening.emit(active)

    def set_thinking(self, active: bool):
        self.sig_thinking.emit(active)


# ── Standalone run ────────────────────────────────────────────────────
if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = JARVISWindow()
    win.log.append_system("JARVIS HUD initialized.")
    win.log.append_jarvis("Good evening. All systems are online.")
    win.show()
    sys.exit(app.exec_())
