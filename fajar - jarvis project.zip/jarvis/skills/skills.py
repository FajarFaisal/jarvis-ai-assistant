"""
JARVIS Skills — command routing + all skill implementations
"""
import os, sys, datetime, webbrowser, subprocess, platform
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from skills.computer_control import (
    type_text, press_key, hotkey, take_screenshot, scroll,
    open_tab, search_google, close_tab,
    create_file, read_file, list_files, open_file,
    send_email, read_emails,
    copy_to_clipboard, get_clipboard,
    set_volume, mute_volume,
)
from config.settings import (
    TAVILY_API_KEY, USE_WEB_SEARCH,
    HOME_ASSISTANT_URL, HOME_ASSISTANT_TOKEN, USE_SMART_HOME,
    USER_NAME,
)

# ═══════════════════════════════════════════════════════════
#  SYSTEM UTILITIES
# ═══════════════════════════════════════════════════════════

def get_system_status() -> str:
    try:
        import psutil
        cpu  = psutil.cpu_percent(interval=1)
        ram  = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        battery = psutil.sensors_battery()
        bat_str = f"{battery.percent:.0f}% {'(charging)' if battery.power_plugged else ''}" if battery else "N/A"
        return (
            f"System status: CPU {cpu}% | "
            f"RAM {ram.used/1e9:.1f}/{ram.total/1e9:.1f} GB | "
            f"Disk {disk.used/1e9:.0f}/{disk.total/1e9:.0f} GB | "
            f"Battery {bat_str}"
        )
    except ImportError:
        return "psutil not installed — system stats unavailable."


def get_time() -> str:
    now = datetime.datetime.now()
    return f"The time is {now.strftime('%I:%M %p')}, {USER_NAME}. Date: {now.strftime('%A, %B %d %Y')}."


# ═══════════════════════════════════════════════════════════
#  WEB SEARCH  (Tavily)
# ═══════════════════════════════════════════════════════════

def web_search(query: str) -> str:
    if not USE_WEB_SEARCH or not TAVILY_API_KEY:
        return ""
    try:
        from tavily import TavilyClient
        client = TavilyClient(api_key=TAVILY_API_KEY)
        response = client.search(query=query, search_depth="basic", max_results=3)
        snippets = [r["content"] for r in response.get("results", [])]
        return "\n".join(snippets[:3]) if snippets else ""
    except Exception as e:
        print(f"[Search] Error: {e}")
        return ""


# ═══════════════════════════════════════════════════════════
#  SMART HOME  (Home Assistant)
# ═══════════════════════════════════════════════════════════

def _ha_request(method: str, endpoint: str, data: dict = None):
    if not USE_SMART_HOME or not HOME_ASSISTANT_URL or not HOME_ASSISTANT_TOKEN:
        return None
    import requests
    headers = {
        "Authorization": f"Bearer {HOME_ASSISTANT_TOKEN}",
        "Content-Type": "application/json",
    }
    url = f"{HOME_ASSISTANT_URL}/api/{endpoint}"
    try:
        if method == "GET":
            return requests.get(url, headers=headers, timeout=5).json()
        elif method == "POST":
            return requests.post(url, headers=headers, json=data, timeout=5).json()
    except Exception as e:
        print(f"[SmartHome] Error: {e}")
        return None


def control_light(entity_id: str, state: str) -> str:
    """state: 'on' or 'off'"""
    service = "light/turn_on" if state == "on" else "light/turn_off"
    result = _ha_request("POST", f"services/{service}", {"entity_id": entity_id})
    if result is not None:
        return f"Light '{entity_id}' turned {state}, {USER_NAME}."
    return "Smart home control is unavailable."


def get_home_status() -> str:
    states = _ha_request("GET", "states")
    if not states:
        return "Smart home is offline or not configured."
    lights_on = [s["entity_id"] for s in states if s["entity_id"].startswith("light.") and s["state"] == "on"]
    return f"{len(lights_on)} light(s) on: {', '.join(lights_on) or 'none'}."


# ═══════════════════════════════════════════════════════════
#  APP LAUNCHER
# ═══════════════════════════════════════════════════════════

APP_MAP = {
    "spotify":    {"windows": "spotify", "darwin": "open -a Spotify", "linux": "spotify"},
    "chrome":     {"windows": "chrome",  "darwin": "open -a 'Google Chrome'", "linux": "google-chrome"},
    "vscode":     {"windows": "code",    "darwin": "open -a 'Visual Studio Code'", "linux": "code"},
    "calculator": {"windows": "calc",    "darwin": "open -a Calculator", "linux": "gnome-calculator"},
    "terminal":   {"windows": "cmd",     "darwin": "open -a Terminal", "linux": "gnome-terminal"},
    "notepad":    {"windows": "notepad", "darwin": "open -a TextEdit", "linux": "gedit"},
}

def open_app(name: str) -> str:
    name = name.lower().strip()
    system = platform.system().lower()
    if name in APP_MAP:
        cmd = APP_MAP[name].get(system, "")
        if cmd:
            subprocess.Popen(cmd, shell=True)
            return f"Opening {name.capitalize()}, {USER_NAME}."
    return f"I don't have '{name}' in my app registry, {USER_NAME}."


def open_website(url: str) -> str:
    if not url.startswith("http"):
        url = "https://" + url
    webbrowser.open(url)
    return f"Opening {url}, {USER_NAME}."


# ═══════════════════════════════════════════════════════════
#  COMMAND ROUTER
# ═══════════════════════════════════════════════════════════

def route(text: str) -> tuple[str | None, bool]:
    """
    Try to handle the command locally.
    Returns (response_str, handled).
    If handled=False, the brain (Claude) should process it.
    """
    t = text.lower().strip()

    # Time / date
    if any(w in t for w in ["what time", "what's the time", "current time", "what date", "today's date"]):
        return get_time(), True

    # System status
    if any(w in t for w in ["system status", "cpu", "ram", "memory", "battery", "disk space"]):
        return get_system_status(), True

    # Open websites
    for site in ["youtube", "google", "github", "netflix", "reddit", "twitter", "x.com"]:
        if f"open {site}" in t:
            return open_website(f"https://www.{site}.com"), True

    # Open apps
    for app in APP_MAP:
        if f"open {app}" in t or f"launch {app}" in t or f"start {app}" in t:
            return open_app(app), True

    # Smart home lights
    if "turn on" in t and ("light" in t or "lights" in t):
        entity = "light.living_room"  # Default; parse entity for full implementation
        return control_light(entity, "on"), True
    if "turn off" in t and ("light" in t or "lights" in t):
        entity = "light.living_room"
        return control_light(entity, "off"), True

    # Home status
    if "home status" in t or "smart home" in t:
        return get_home_status(), True

    # ── Browser control ───────────────────────────────────────────────
    if "open tab" in t or "new tab" in t:
        # e.g. "open tab youtube.com"
        parts = t.replace("open tab", "").replace("new tab", "").strip()
        if parts:
            return open_tab(parts), True

    if "search for" in t or "google" in t and "search" in t:
        query = t.replace("search for", "").replace("google", "").replace("search", "").strip()
        return search_google(query), True

    if "close tab" in t:
        return close_tab(), True

    # ── Screenshot ────────────────────────────────────────────────────
    if "take a screenshot" in t or "screenshot" in t:
        return take_screenshot(), True

    # ── Clipboard ─────────────────────────────────────────────────────
    if "what's in my clipboard" in t or "read clipboard" in t:
        return get_clipboard(), True

    # ── Files ─────────────────────────────────────────────────────────
    if "list files" in t or "list my files" in t:
        folder = "~"
        if "desktop" in t:
            folder = "~/Desktop"
        elif "downloads" in t:
            folder = "~/Downloads"
        elif "documents" in t:
            folder = "~/Documents"
        return list_files(folder), True

    # ── Emails ────────────────────────────────────────────────────────
    if "check my email" in t or "read my email" in t or "any emails" in t:
        return read_emails(), True

    # ── Volume ────────────────────────────────────────────────────────
    if "mute" in t:
        return mute_volume(), True
    if "volume" in t:
        for word in t.split():
            if word.isdigit():
                return set_volume(int(word)), True

    # ── Scroll ────────────────────────────────────────────────────────
    if "scroll down" in t:
        return scroll("down"), True
    if "scroll up" in t:
        return scroll("up"), True

    # ── Keyboard shortcuts ────────────────────────────────────────────
    if "press enter" in t:
        return press_key("enter"), True
    if "press escape" in t or "press esc" in t:
        return press_key("escape"), True
    if "copy" in t and "clipboard" not in t:
        return hotkey("ctrl", "c"), True
    if "paste" in t:
        return hotkey("ctrl", "v"), True
    if "undo" in t:
        return hotkey("ctrl", "z"), True
    if "select all" in t:
        return hotkey("ctrl", "a"), True

    # Not handled locally — let the brain decide
    return None, False
