"""
JARVIS Computer Control — pyautogui + Gmail API + browser automation
Gives JARVIS full control over your PC
"""
import os, sys, time, subprocess, platform
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import USER_NAME

# ═══════════════════════════════════════════════════════════
#  MOUSE & KEYBOARD  (pyautogui)
# ═══════════════════════════════════════════════════════════

def _gui():
    import pyautogui
    pyautogui.FAILSAFE = True   # Move mouse to top-left corner to abort
    pyautogui.PAUSE = 0.05
    return pyautogui

def click(x: int, y: int) -> str:
    _gui().click(x, y)
    return f"Clicked at ({x}, {y})."

def type_text(text: str, interval: float = 0.04) -> str:
    _gui().typewrite(text, interval=interval)
    return f"Typed: {text}"

def press_key(key: str) -> str:
    _gui().press(key)
    return f"Pressed '{key}'."

def hotkey(*keys) -> str:
    _gui().hotkey(*keys)
    return f"Hotkey: {'+'.join(keys)}"

def take_screenshot(filename: str = "screenshot.png") -> str:
    path = os.path.join(os.path.expanduser("~"), "Desktop", filename)
    _gui().screenshot(path)
    return f"Screenshot saved to {path}, {USER_NAME}."

def scroll(direction: str = "down", clicks: int = 3) -> str:
    amount = -clicks if direction == "down" else clicks
    _gui().scroll(amount)
    return f"Scrolled {direction}."

# ═══════════════════════════════════════════════════════════
#  BROWSER CONTROL  (selenium)
# ═══════════════════════════════════════════════════════════

_driver = None

def _get_driver():
    global _driver
    if _driver is not None:
        return _driver
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from webdriver_manager.chrome import ChromeDriverManager

    options = Options()
    options.add_argument("--start-maximized")
    options.add_experimental_option("detach", True)  # Keep browser open
    _driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options,
    )
    return _driver

def open_tab(url: str) -> str:
    if not url.startswith("http"):
        url = "https://" + url
    try:
        driver = _get_driver()
        driver.execute_script(f"window.open('{url}', '_blank');")
        driver.switch_to.window(driver.window_handles[-1])
        return f"Opened {url} in a new tab, {USER_NAME}."
    except Exception as e:
        return f"Browser error: {e}"

def search_google(query: str) -> str:
    import urllib.parse
    url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
    return open_tab(url)

def close_tab() -> str:
    try:
        _get_driver().close()
        return "Tab closed."
    except Exception as e:
        return f"Error: {e}"

def get_page_title() -> str:
    try:
        return f"Current page: {_get_driver().title}"
    except:
        return "No browser open."

# ═══════════════════════════════════════════════════════════
#  FILE MANAGEMENT
# ═══════════════════════════════════════════════════════════

def create_file(path: str, content: str = "") -> str:
    try:
        full_path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w") as f:
            f.write(content)
        return f"File created at {full_path}, {USER_NAME}."
    except Exception as e:
        return f"File error: {e}"

def read_file(path: str) -> str:
    try:
        full_path = os.path.expanduser(path)
        with open(full_path, "r") as f:
            content = f.read()
        return f"Contents of {path}:\n{content}"
    except Exception as e:
        return f"Could not read file: {e}"

def list_files(directory: str = "~") -> str:
    try:
        full_path = os.path.expanduser(directory)
        files = os.listdir(full_path)
        return f"Files in {directory}: {', '.join(files[:20])}"
    except Exception as e:
        return f"Directory error: {e}"

def open_file(path: str) -> str:
    try:
        full_path = os.path.expanduser(path)
        if platform.system() == "Windows":
            os.startfile(full_path)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", full_path])
        else:
            subprocess.Popen(["xdg-open", full_path])
        return f"Opening {path}, {USER_NAME}."
    except Exception as e:
        return f"Could not open file: {e}"

# ═══════════════════════════════════════════════════════════
#  GMAIL  (Gmail API)
# ═══════════════════════════════════════════════════════════

def _gmail_service():
    """Initialize Gmail API service (requires credentials.json from Google Cloud)."""
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build

    SCOPES = ["https://www.googleapis.com/auth/gmail.modify"]
    creds = None
    token_path = os.path.join(os.path.dirname(__file__), "..", "data", "gmail_token.json")
    creds_path = os.path.join(os.path.dirname(__file__), "..", "data", "credentials.json")

    if os.path.exists(token_path):
        creds = Credentials.from_authorized_user_file(token_path, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(creds_path, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(token_path, "w") as f:
            f.write(creds.to_json())

    return build("gmail", "v1", credentials=creds)

def send_email(to: str, subject: str, body: str) -> str:
    try:
        import base64
        from email.mime.text import MIMEText

        service = _gmail_service()
        message = MIMEText(body)
        message["to"]      = to
        message["subject"] = subject
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        service.users().messages().send(userId="me", body={"raw": raw}).execute()
        return f"Email sent to {to}, {USER_NAME}."
    except Exception as e:
        return f"Email error: {e}"

def read_emails(max_results: int = 5) -> str:
    try:
        service = _gmail_service()
        results = service.users().messages().list(
            userId="me", labelIds=["INBOX"], maxResults=max_results
        ).execute()
        messages = results.get("messages", [])
        if not messages:
            return "No new emails."

        summaries = []
        for msg in messages[:max_results]:
            detail = service.users().messages().get(
                userId="me", id=msg["id"], format="metadata",
                metadataHeaders=["From", "Subject"]
            ).execute()
            headers = {h["name"]: h["value"] for h in detail["payload"]["headers"]}
            summaries.append(f"From: {headers.get('From','?')} | {headers.get('Subject','(no subject)')}")

        return f"Latest {len(summaries)} emails:\n" + "\n".join(summaries)
    except Exception as e:
        return f"Could not read emails: {e}"

# ═══════════════════════════════════════════════════════════
#  CLIPBOARD
# ═══════════════════════════════════════════════════════════

def copy_to_clipboard(text: str) -> str:
    try:
        import pyperclip
        pyperclip.copy(text)
        return f"Copied to clipboard, {USER_NAME}."
    except Exception as e:
        return f"Clipboard error: {e}"

def get_clipboard() -> str:
    try:
        import pyperclip
        content = pyperclip.paste()
        return f"Clipboard contains: {content[:200]}"
    except Exception as e:
        return f"Clipboard error: {e}"

# ═══════════════════════════════════════════════════════════
#  VOLUME CONTROL
# ═══════════════════════════════════════════════════════════

def set_volume(level: int) -> str:
    """level: 0-100"""
    try:
        if platform.system() == "Windows":
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMasterVolumeLevelScalar(level / 100, None)
        elif platform.system() == "Darwin":
            subprocess.run(["osascript", "-e", f"set volume output volume {level}"])
        else:
            subprocess.run(["amixer", "-D", "pulse", "sset", "Master", f"{level}%"])
        return f"Volume set to {level}%, {USER_NAME}."
    except Exception as e:
        return f"Volume error: {e}"

def mute_volume() -> str:
    try:
        _gui().hotkey("volumemute")
        return "Muted, {USER_NAME}."
    except Exception as e:
        return f"Mute error: {e}"
